package com.example.ejerguia7

import android.widget.EditText
import java.util.regex.Pattern

class UValidator2 {
    fun validateDUI(editar: EditText, errorMessage: String): Boolean {
        val pattern = Pattern.compile("^[0-9]{8}-[0-9]$")
        val matcher = pattern.matcher(editar.text.toString())
        if (!matcher.find()) {
            editar.error = errorMessage
            return false
        }
        return true
    }

    fun validateNIT(editar: EditText, errorMessage: String): Boolean {
        val pattern = Pattern.compile("^[0-9]{4}-[0-9]{6}-[0-9]{3}-[0-9]$")
        val matcher = pattern.matcher(editar.text.toString())
        if (!matcher.find()) {
            editar.error = errorMessage
            return false
        }
        return true
    }

    fun validateUDBCarnet(editar: EditText, errorMessage: String): Boolean {
        val pattern = Pattern.compile("^[a-z]{2}[0-9]{6}$", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(editar.text.toString())
        if (!matcher.find()) {
            editar.error = errorMessage
            return false
        }
        return true
    }

    fun validateEmail(editar: EditText, errorMessage: String): Boolean {
        val pattern = Pattern.compile("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(editar.text.toString())
        if (!matcher.find()) {
            editar.error = errorMessage
            return false
        }
        return true
    }

    fun validateNotEmpty(editar: EditText, errorMessage: String): Boolean {
        val text = editar.text.toString().trim()
        if (text.isEmpty()) {
            editar.error = errorMessage
            return false
        }
        return true
    }

    fun customRegex(editar: EditText, regexPattern: String, errorMessage: String): Boolean {
        val pattern = Pattern.compile(regexPattern)
        val matcher = pattern.matcher(editar.text.toString())
        if (!matcher.find()) {
            editar.error = errorMessage
            return false
        }
        return true
    }
}