package com.example.ejerguia7

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ejerguia7.util.UValidator2

class MainActivity : AppCompatActivity() {

    lateinit var nombre: EditText
    lateinit var carnet: EditText
    lateinit var dui: EditText
    lateinit var nit: EditText
    lateinit var email: EditText
    lateinit var comentarios: EditText
    lateinit var telefono: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        nombre = findViewById(R.id.nombre)
        carnet = findViewById(R.id.carnet)
        dui = findViewById(R.id.dui)
        nit = findViewById(R.id.nit)
        email = findViewById(R.id.email)
        comentarios = findViewById(R.id.comentarios)
        telefono = findViewById(R.id.telefono)
    }

    fun validar(view: View) {
        if (validateFields()) {
            Toast.makeText(this, "LOS CAMPOS SON CORRECTOS", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "ERROR DE VALIDACIONES", Toast.LENGTH_LONG).show()
        }
    }

    private fun validateFields(): Boolean {
        var status = true
        if (!UValidator.validateUDBCarnet(carnet, "Carnet incorrecto")) {
            status = false
        }
        if (!UValidator.validateEmail(email, "Email incorrecto")) {
            status = false
        }
        if (!UValidator.validateDUI(dui, "DUI Incorrecto")) {
            status = false
        }
        if (nit.text.toString().length > 0 && !UValidator2.validateNIT(nit, "Nit incorrecto")) {
            status = false
        }
        if (!UValidator2.validateNotEmpty(nombre, "Ingrese un nombre")) {
            status = false
        }
        if (!UValidator2.customRegex(telefono, "^[0-9]{4}-[0-9]{4}$", "Teléfono incorrecto")) {
            status = false
        }
        return status
    }
}