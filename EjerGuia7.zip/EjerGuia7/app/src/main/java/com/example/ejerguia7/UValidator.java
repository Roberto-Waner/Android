package com.example.ejerguia7;


import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UValidator {
    public static boolean validateDUI(EditText editar, String errorMessage){
        Pattern pattern = Pattern.compile("^[0-9]{8}-[0-9]$");

        Matcher matcher = pattern.matcher(editar.getText().toString());

        if (!matcher.find()){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }

    public static boolean validateNIT (EditText editar, String errorMessage){
        Pattern pattern = Pattern.compile("^[0-9]{4}-[0-9]{6}-[0-9]{3}-[0-9]$");
        Matcher matcher = pattern.matcher(editar.getText().toString());

        if (!matcher.find()){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }

    public static boolean validateUDBCarnet(EditText editar, String errorMessage){
        Pattern pattern = Pattern.compile("^[a-z]{2}[0-9]{6}$",Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(editar.getText().toString());

        if(!matcher.find()){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }

    public static boolean validateEmail(EditText editar, String errorMessage){
        Pattern pattern = Pattern.compile("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$",Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(editar.getText().toString());

        if(!matcher.find()){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }

    public static boolean validateNotEmpty(EditText editar, String errorMessage){
        String text = editar.getText().toString().trim();

        if(text.length()==0){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }

    public static boolean customRegex(EditText editar, String regexPattern,String errorMessage){
        Pattern pattern = Pattern.compile(regexPattern);
        Matcher matcher = pattern.matcher(editar.getText().toString());

        if(!matcher.find()){
            editar.setError(errorMessage);
            return false;
        }
        return true;
    }
}
