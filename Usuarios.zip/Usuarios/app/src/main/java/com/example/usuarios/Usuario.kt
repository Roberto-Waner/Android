package com.example.usuarios

class Usuario {
    var id: Int = 0
    var nombre:String =""
    var edad: Int = 0

    constructor(nombre:String, edad:Int){
        this.nombre=nombre
        this.edad=edad
    }

    constructor(){}
}