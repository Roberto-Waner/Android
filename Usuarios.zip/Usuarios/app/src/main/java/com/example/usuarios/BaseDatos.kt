package com.example.usuarios

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf

var BD="Datos"

class BaseDatos(contexto:Context):SQLiteOpenHelper(contexto, BD, null, 1) {
    override fun onCreate(db: SQLiteDatabase?) {

        val sql = "Create table Usuario (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre VARCHAR(256), edad INTEGER)";
        db?.execSQL(sql)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun insertarDatos(usuario: Usuario):String{
        val db = this.writableDatabase
        val contenedor = contentValuesOf()

        contenedor.put("nombre", usuario.nombre)
        contenedor.put("edad", usuario.edad)

        var resultado = db.insert("Usuario", null, contenedor)
        if (resultado == -1.toLong()){
            return "Error en Proceso de Insercion"
        }
        else{
            return "Insert Exitoso"
        }
    }

    @SuppressLint("Range")
    fun listarDatos():MutableList<Usuario>{
        var lista:MutableList<Usuario> = ArrayList()
        val db = this.readableDatabase
        val sql = "select * from Usuario"
        val resultado = db.rawQuery(sql,null)

        if (resultado.moveToFirst()){
            do {
                var usu = Usuario()
                usu.id = resultado.getString(resultado.getColumnIndex("id")).toInt()
                usu.nombre = resultado.getString(resultado.getColumnIndex("nombre"))
                usu.edad = resultado.getString(resultado.getColumnIndex("edad")).toInt()
                lista.add(usu)
            }while (resultado.moveToNext())
            resultado.close()
            db.close()
        }
        return lista
    }

    fun actualizar(id:String, nombre:String, edad:Int):String{
        val db = this.writableDatabase
        var contenedordeValores = ContentValues()
        contenedordeValores.put("nombre", nombre)
        contenedordeValores.put("edad", edad)

        var resultado = db.update("Usuario", contenedordeValores, "id = ?", arrayOf(id))

        if (resultado>0){
            return "Actualizacion Realizada"
        }else{
            return "Actualizacion no Realizada"
        }
    }

    fun borrarDatos(id: String, nombre: String, edad: Int){
        val db = writableDatabase

        if (id.length>0){
            db.delete("Usuario", "id = ?", arrayOf(id))
        }
    }
}