plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.jetbrainsKotlinAndroid)
}

android {
    namespace = "com.example.guia2"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.guia2"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    //Librería RecyclerView
    //La versión dependerá de la API que esté utilizando en su proyecto.
    implementation 'com.android.support:cardview-v7:25.4.0'
    implementation 'com.android.support:recyclerview-v7:25.4.0'

    //Volley
    implementation 'com.android.volley:volley:1.0.0'

    //Glide y wasabi transformation
    //https://github.com/wasabeef/glide-transformations
    implementation 'com.github.bumptech.glide:glide:3.6.1'
    implementation 'jp.wasabeef:glide-transformations:2.0.1'

    // If you want to use the GPU Filters
    implementation 'jp.co.cyberagent.android.gpuimage:gpuimage-library:1.3.0'

    //Parseando los objetos rapido con Gson
    implementation 'com.google.code.gson:gson:2.3.1'

    //Librería de Picasso
    implementation 'com.squareup.picasso:picasso:2.5.2'

}