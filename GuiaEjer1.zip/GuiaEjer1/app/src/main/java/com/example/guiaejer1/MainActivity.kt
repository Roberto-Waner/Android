package com.example.guiaejer1

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Context
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Vibrator
import android.util.Log
import kotlin.math.roundToInt

abstract class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var containerView: ContainerView
    private lateinit var sensorManager: SensorManager
    private lateinit var sensorAccelerometer: Sensor
    private lateinit var sensorLight: Sensor
    private lateinit var v: Vibrator
    private val vibrationTime = 25

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        containerView = findViewById(R.id.container)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        sensorAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!!
        sensorManager.registerListener(this, sensorAccelerometer, SensorManager.SENSOR_DELAY_GAME)

        sensorLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)!!
        sensorManager.registerListener(this, sensorLight, SensorManager.SENSOR_DELAY_GAME)

        v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    override fun onSensorChanged(event: SensorEvent) {
        val sensor = event.sensor
        when (sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                containerView.containerWidth =
                    (containerView.containerWidth.coerceIn(0,
                        containerView.width.toDouble().roundToInt()
                    ) - x * 2).roundToInt()

                containerView.containerHeight =
                    (containerView.containerHeight.coerceIn(0,
                        containerView.height.toDouble().roundToInt()
                    ) + y * 2).roundToInt()

                if (containerView.containerWidth.toDouble() == 0.0 || containerView.containerWidth.toDouble() == containerView.width.toDouble() ||
                    containerView.containerHeight.toDouble() == 0.0 || containerView.containerHeight.toDouble() == containerView.height.toDouble()) {
                    v.vibrate(vibrationTime)
                }
            }
            Sensor.TYPE_LIGHT -> {
                val light = event.values[0] / 500.0f
                containerView.color = if (light > 1) Color.WHITE else {
                    val colorValue = (255 * light).roundToInt()
                    Color.rgb(colorValue, colorValue, colorValue)
                }
            }
        }
        containerView.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

}

private fun Vibrator.vibrate(vibrationTime: Int) {
    TODO("Not yet implemented")
}
