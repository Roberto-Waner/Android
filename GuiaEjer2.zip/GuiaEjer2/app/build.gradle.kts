plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.guiaejer2"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.guiaejer2"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {

    //noinspection GradleCompatible,GradleCompatible,GradleCompatible,GradleCompatible
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // Librería RecyclerView
    //noinspection GradleCompatible
    implementation("androidx.cardview:cardview:1.0.0")
    //noinspection GradleCompatible
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    // Volley
    implementation("com.android.volley:volley:1.2.1")
    // Glide y wasabi transformation
    implementation("com.github.bumptech.glide:glide:5.0.0-rc01")
    implementation("jp.wasabeef:glide-transformations:2.0.1")
    // If you want to use the GPU Filters
    implementation("jp.co.cyberagent.android.gpuimage:gpuimage-library:1.3.0")
    // Parseando los objetos rápido con Gson
    implementation ("com.google.code.gson:gson:2.9.1")
    // Librería de Picasso
    implementation("com.squareup.picasso:picasso:2.5.2")
}