package com.example.guiaejer2;

import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    ImageView teamImage;
    TextView teamDescription;
    WebView teamVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Team team = (Team) getIntent().getSerializableExtra("teamdetail");

        teamVideo = findViewById(R.id.video);
        teamImage = findViewById(R.id.teamImage);
        teamDescription = findViewById(R.id.teamDescription);

        WebSettings settings = teamVideo.getSettings();
        settings.setJavaScriptEnabled(true);
        teamVideo.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);

        teamVideo.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return false;
            }
        });

        if(team.getVideoUrl() != null){
            Uri uri = Uri.parse(team.getVideoUrl());
            teamVideo.loadUrl(team.getVideoUrl());
        }

        teamDescription.setText(team.getDescription());

        Glide.with(this).load(team.getImgLogo()).fitCenter().circleCrop().into(teamImage);
    }
}

