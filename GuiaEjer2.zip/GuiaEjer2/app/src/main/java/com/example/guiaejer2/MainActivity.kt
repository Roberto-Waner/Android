package com.example.guiaejer2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.res.Resources
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var urlJson: String? = null
    private val teams: MutableList<Team> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlJson = getString(R.string.url_json)
    }

    override fun onResume() {
        super.onResume()
        initContent()
    }

    override fun onPause() {
        teams.clear()
        super.onPause()
    }

    private fun initContent() {
        val requestQueue: RequestQueue = Volley.newRequestQueue(this)
        val jsonArrayRequest = JsonArrayRequest(urlJson,
            { response ->
                try {
                    parseContent(response)
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            { })
        requestQueue.add(jsonArrayRequest)
    }

    @Throws(JSONException::class)
    private fun parseContent(jsonArray: JSONArray) {
        for (i in 0 until jsonArray.length()) {
            val tmp: JSONObject = jsonArray.getJSONObject(i)
            val gson = Gson()
            val t: Team = gson.fromJson(tmp.toString(), Team::class.java)
            teams.add(t)
        }
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = TeamItemAdapter(teams, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}