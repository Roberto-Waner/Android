package com.example.guiaejer2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.res.Resources
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var urlJson: String
    private val teams = ArrayList<Team>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val res: Resources = this.resources
        urlJson = res.getString(R.string.url_json)
    }

    override fun onResume() {
        super.onResume()
        initContent()
    }

    override fun onPause() {
        teams.clear()
        super.onPause()
    }

    private fun initContent() {
        val requestQueue: RequestQueue = Volley.newRequestQueue(this)
        val jsonArrayRequest = JsonArrayRequest(urlJson,
            Response.Listener<JSONArray> { response ->
                try {
                    parseContent(response)
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { })
        requestQueue.add(jsonArrayRequest)
    }

    @Throws(JSONException::class)
    private fun parseContent(jsonArray: JSONArray) {
        for (i in 0 until jsonArray.length()) {
            val tmp: JSONObject = jsonArray.getJSONObject(i)
            val gson = Gson()
            val t: Team = gson.fromJson(tmp.toString(), Team::class.java)
            teams.add(t)
        }
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = TeamItemAdapter(teams, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}